<?php $__env->startSection('content'); ?>
    <div class="container" style="height: 65vh">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card mt-4">
                    <div class="card-header text-center">
                        <img src="<?php echo e(asset('svg/dove.svg' )); ?>" style="height: 50px; width: 50px">
                    </div>
                    <div class="card-body text-center">
                        <h2 class="mt-4">Seems like you got lost and ended up here...</h2>
                        <a href="<?php echo e(route('home.index')); ?>" class="btn btn-primary mt-4">Browse Restaurants</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Restaurant(pigeons)\resources\views/fallback.blade.php ENDPATH**/ ?>