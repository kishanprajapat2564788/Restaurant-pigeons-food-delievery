@auth()
    @include('layouts.dashboard.navbars.auth')
@endauth
