<footer class="footer">
    @include('layouts.dashboard.footers.footer')
</footer>
